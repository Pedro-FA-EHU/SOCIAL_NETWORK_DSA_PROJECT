package packUser;

import packEx.*;
import packList.*;


public class Person {

	private String id;
	private String name;
	private String lastname;
	private String birthdate;
	private String gender;
	private String birthplace;
	private String home;
	private String[] studiedat;
	private String[] workplaces;
	private String[] films;
	private  LinkedList<String> friendships;
	private String groupcode= "G612498"; //groupcode by defect
	
	
	public Person(String pId,String pName,String pLastName,String pBirthDate,String pGender,String pBirthPlace, String pHome, String[] pStudieDat, String[] pWorkPlaces, String[] pFilms, String pGroupcode) throws EmptyIDEx{ //ExistingIDException
		if(pId==null || pId=="") {
			throw new EmptyIDEx();
		}
		
		else {
			id=pId;
			name=pName;
			lastname=pLastName;
			birthdate=pBirthDate;
			gender=pGender;
			birthplace=pBirthPlace;
			home=pHome;
			studiedat=pStudieDat;
			workplaces=pWorkPlaces;
			films=pFilms;
			//After reading "friends.txt" --> 
			//Relations among users are created in each person attribute "friendships".
			friendships=new LinkedList<>();
			groupcode=pGroupcode;
		}			
	}
	// Getters and Setters can be implemented depending on the Social Network possibilities. 
	//Maybe we want to know only someone id.
		public String getId() {
			return id;
		}
		
		public String getName() {
			return name;
		}
		
		public LinkedList<String> getFriendships() {
			return friendships;
		}
		
		public String getFriendshipsString() {
			String s=new String();
			for(int i=0;i<this.getFriendships().size();i++) {
				try {
				if(i==this.getFriendships().size()-1) {
					s+=this.getFriendships().getElement(i);
				}
				else {
					s+=this.getFriendships().getElement(i)+",";
					
				}
				}
				catch(AccessOutOfBoundariesEx e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
			}
			return s;
		}
		
		public String getBirthplace() {
			return birthplace;
		}
		public String getSurname() {
			return lastname;
		}
		@Override
		public String toString() {			
			String studieDat = new String();
			String workPlaces = new String();
			String films = new String();
			//Array to String Transformation of studiedat
			try {
				for (int i=0;i<this.studiedat.length;i++) {
					studieDat+=this.studiedat[i]+",";
				}
				// Replacing last character of the String, "," --> ";" 
				studieDat=studieDat.substring(0,studieDat.length()-1)+";";
			} catch(NullPointerException e) {
				studieDat=";";
			}
			//Array to String Transformation of films
			try {
				for (int i=0;i<this.films.length;i++) {
					films+=this.films[i]+",";
				}
				// Replacing last character of the String, "," --> ";"
				films=films.substring(0,films.length()-1)+";";
			} catch(NullPointerException e) {
				workPlaces=";";
			}
			//Array to String Transformation of workplaces
			try {
				for (int i=0;i<this.workplaces.length;i++) {
					workPlaces+=this.workplaces[i]+",";
				}
				// Replacing last character of the String, "," --> ";"
				workPlaces=workPlaces.substring(0,workPlaces.length()-1)+";";
			} catch(NullPointerException e ) {
				films=";";
			}

			return this.id+","+this.name+","+this.lastname+","+this.birthdate+","+this.gender+","+this.birthplace+","+this.home+","+studieDat+workPlaces+films+this.groupcode;
		}
}
