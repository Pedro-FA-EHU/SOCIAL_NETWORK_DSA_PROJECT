package packUser;

import java.util.Arrays;
import packList.*;
import packEx.*;

public class UsersList extends LinkedList<Person>{
	//Constructor
	public UsersList () {
		super();
	}
	//Our own methods
	public boolean repeatedID(String s) throws ExistingIDEx{
		boolean repeated=false;
		int j=0;
		while(!repeated && j<size()) {
			try {
			if(getElement(j).getId().equals(s)) {
				repeated=true;
				throw new ExistingIDEx();
			}
			else {
				j++;
			}
			} catch(AccessOutOfBoundariesEx e) {
				System.out.println(e.getMessage());
			} catch(EmptyCollectionEx e) {
				System.out.println(e.getMessage());
			}
		}
		return repeated;
	}
	public void loadPerson(String user) {
		//We expect the client introduces the user information as expected in the
		//project specifications
		//idperson,name,lastname,birthdate,gender,birthplace,
		//home,studiedat;workplaces;films;groupcode
		
		// RA -> Repeatable Attributes (studiedat,workplaces,films)
		// URA -> Unrepeatable Attributes (idperson,name,lastname,...,groupcode)
		
		String[] personArrayRA=user.split(";");
		String[] personArrayURA= personArrayRA[0].split(",");	
		
		try {
			String id = personArrayURA[0];
			String name = personArrayURA[1];
			String lastname = personArrayURA[2];
			String birthdate = personArrayURA[3];
			String gender = personArrayURA[4];
			String birthplace = personArrayURA[5];
			String home = personArrayURA[6];
			String[] studiedat = Arrays.copyOfRange(personArrayURA, 7, 
					personArrayURA.length);
			String[] workplaces = personArrayRA[1].split(",");
			String[] films = personArrayRA[2].split(",");
			
			// Just in case, ... ;G6,watermelon,orange,apple,... (Incorrect Structure of User Information)
			String groupcode = personArrayRA[3].split(",")[0];
			if( repeatedID(id)==false ) {
				Person s = new Person(id, name, lastname, birthdate, gender, birthplace, home, studiedat, workplaces, films, groupcode);
				//Insert in order
				insert(s,size()-1);
			}
		} catch(ExistingIDEx e) {
			System.out.println(e.getMessage());
			System.out.println("Please, introduce another ID."+ personArrayURA[0] + " not valid.");
		} catch(EmptyIDEx e) {
			System.out.println(e.getMessage());
			System.out.println("Please, introduce an ID.");
		} catch(AccessOutOfBoundariesEx e) {
			System.out.println(e.getMessage());
		}
		
		  catch(ArrayIndexOutOfBoundsException e) {
			  System.out.println("Please enter user information in the correct structure way.");
		  }
		 
	}
	public Person search (String id) {
		Person p = null;
		try {
			boolean userFound = false;
			int i=0;
			while(!userFound && i<this.size()) {
				if(this.getElement(i).getId().equals(id)) {
					userFound=true;
				    p = this.getElement(i);
				}
				i++;
			}
			// if(!userFound) return initial null value
		} catch(AccessOutOfBoundariesEx e) {
			System.out.println(e.getMessage());
		} catch(EmptyCollectionEx e) {
			System.out.println(e.getMessage());
		} 
		return p;
	}
}
