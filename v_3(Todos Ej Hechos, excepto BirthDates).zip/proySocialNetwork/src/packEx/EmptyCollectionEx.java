package packEx;
/*This exception is thrown when we want to perform some illegal operation
on an empty collection */
public class EmptyCollectionEx extends Exception{
	public EmptyCollectionEx() {
		super();
	}
	public EmptyCollectionEx(String message) {
		super(message);
	}
}
