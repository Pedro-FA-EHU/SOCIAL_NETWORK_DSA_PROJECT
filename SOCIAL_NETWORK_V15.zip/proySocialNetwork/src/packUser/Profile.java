package packUser;

import packEx.*;

import packList.*;

public class Profile {

	private String name;
	private UsersList userFavouriteMovies;
	
	public Profile(String name, Person p) {
		//Name será la lista de películas
		this.name=name;
		try {
			userFavouriteMovies=new UsersList();
			userFavouriteMovies.insert(p,0);
		}
		catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public Person getPerson() {
		Person p=null;
		try {
			p=this.userFavouriteMovies.getElement(0);
		}
		catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		catch(EmptyCollectionEx e) {
			System.out.println(e.getMessage());
		}
		return p;
	}
	
	
	public void setUserMoviesFavourites(Person p) {
		try {
			userFavouriteMovies.insert(p, userFavouriteMovies.size()-1);
		}
		catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public String getName() {
		return name;
	}
	public UsersList getUserFavouriteMovies(){
		return this.userFavouriteMovies;
	}
	
	
	
	public boolean equals(Profile pr) {
		boolean movie2Inmovie1=true;
		boolean same=true;
		int i=0;
		int j=0;
		String[] movies1=this.name.split(",");
		String[] movies2=pr.name.split(",");
		if(this.name.length()==pr.name.length()) {
			while(i<movies1.length&&movie2Inmovie1) {
				movie2Inmovie1=false;
				while(j<movies2.length) {
					if(movies1[i].equals(movies2[j])) {
						movie2Inmovie1=true;
					}
					j++;	
				}
				i++;
			}
		}
		else {
			same=false;
		}
		if(!(i==movies1.length)|| !(j==movies2.length)) {
			same=false;
		}
		return same;
	}
	
	
}
