package packEx;

public class WrongDateFormatEx extends Exception{
	public WrongDateFormatEx() {
		super();
	}
	public WrongDateFormatEx(String message) {
		super(message);
	}
}
