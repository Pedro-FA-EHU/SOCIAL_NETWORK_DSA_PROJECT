package packGraph;

public interface GraphADT<T>{
	public int V();
	public int E();
	public void addEdge(T e, T f);
	public void addVertex(T elem);
	public void rmEdge(T e, T f);
	public void rmVertex(T elem);
}
