package packComparators;
import packUser.Person;
import java.util.Comparator;

public class UserNameComparator implements Comparator<Person>{
	@Override
	public int compare(Person p1, Person p2) {
		return p1.getName().toUpperCase().compareTo(p2.getName().toUpperCase());
		//toUpperCase avoids ambiguity when comparing lower case strings to upper strings ones
	}
}