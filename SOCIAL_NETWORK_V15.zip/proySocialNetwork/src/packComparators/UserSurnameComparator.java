package packComparators;
import packUser.Person;
import java.util.Comparator;

public class UserSurnameComparator implements Comparator<Person>{
	@Override
	public int compare(Person p1, Person p2) {
		return p1.getSurname().toUpperCase().compareTo(p2.getSurname().toUpperCase());
		//toUpperCase avoids ambiguity when comparing lower case strings to upper strings ones
	}
}
