package packList;

import packEx.*;

public interface ListADT<T>{
	public void insert (T element, int pos) throws IndexOutOfBoundsException;
	public T getElement (int pos) throws IndexOutOfBoundsException, EmptyCollectionEx;
	public void setElement (int pos, T elem) throws IndexOutOfBoundsException, EmptyCollectionEx;
	public int getPosition (T element) throws EmptyCollectionEx;
	public void remove (T element) throws EmptyCollectionEx;
	public T getHead() throws EmptyCollectionEx;
	public T getTail() throws EmptyCollectionEx;
	public boolean contains (T element);
	public boolean isEmpty();
	public int size ();
}
