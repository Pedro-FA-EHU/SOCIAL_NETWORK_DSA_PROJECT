package packEx;
/* This exception is thrown when an attempt of collection access fails because
the position we tried to access does not belongs to the indexes range */
public class AccessOutOfBoundariesEx extends Exception{
	public AccessOutOfBoundariesEx() {
		super();
	}
	public AccessOutOfBoundariesEx(String message) {
		super(message);
	}
}
