package packComparators;
import packUser.Person;
import java.util.Comparator;

import packEx.EmptyCollectionEx;
import packList.LinkedList;

public class UserChainedComparator implements Comparator<Person>{
	private LinkedList<Comparator<Person>> listComparators;
	public UserChainedComparator (UserBirthplaceComparator c1, UserNameComparator c2, UserSurnameComparator c3) {
		this.listComparators = new LinkedList<Comparator<Person>>();
		this.listComparators.insert(c1, 0);
		this.listComparators.insert(c2, 1);
		this.listComparators.insert(c3, 2);
	}
	@Override
	public int compare(Person p1, Person p2) {
		for(int i=0; i<listComparators.size(); i++) {
			try {
				int result = listComparators.getElement(i).compare(p1, p2);
				if (result != 0) {
					return result;
				}
			} catch (IndexOutOfBoundsException e) {
				e.printStackTrace();
			} catch (EmptyCollectionEx e) {
				e.printStackTrace();
			}
		}
		return 0;
	}
}
