package packHash;

public class Hash<E> {
	private E key;
	private int value;
	//Constructor
	public Hash(E k, int v) {
		key = k;
		value = v;
	}
	//Getters
	public E getKey() {
		return key;
	}
	public int getValue() {
		return value;
	}
	//Own methods
	public void decreaseValue() {
		--value;
	}
}
