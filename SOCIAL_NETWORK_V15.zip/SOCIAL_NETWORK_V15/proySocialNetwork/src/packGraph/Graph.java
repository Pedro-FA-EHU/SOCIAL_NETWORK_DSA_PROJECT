package packGraph;

import packEx.*;
import packHash.*;
import packList.*;
import packStack.*;

public class Graph<T> implements GraphADT<T>{
	//Static attributes
	protected HashTable<T> table;
	protected int vertexes;
	protected int edges;
	protected boolean[][] adjacency;
	//Constructor
	public Graph() { //Empty graph
		table = new HashTable<T>();
		vertexes = edges = 0;
		adjacency = new boolean[0][0]; //matrix of dimension 0x0
	}
	//Getters
	public HashTable<T> table() {
		return table;
	}
	public boolean[][] adj() {
		return adjacency;
	}
	//Interface methods
	public int V() {
		return vertexes;
	}
	public int E() {
		return edges;
	}
	public void addEdge(T e, T f) {
		//Check that elements E and F are in the graph
		if (table.getHash(e) != null && table.getHash(f) != null) {
			int v = table.getHash(e).getValue();
			int w = table.getHash(f).getValue();
			adjacency[v][w] = true;
			adjacency[w][v] = true;
			edges++;
		}
	}
	public void addVertex(T elem) {
		//Create a Hash indexed according to the insertion order
		Hash<T> hash = new Hash<T>(elem, vertexes);
		table.insert(hash, vertexes);
		vertexes++;
		//Redimensionate adj matrix 
		boolean[][] aux = new boolean[vertexes][vertexes];
		if (aux.length == 1) {
			aux[0][0] = false;
		} else {
			for (int i=0; i<vertexes; i++) {
				for (int j=0; j<vertexes; j++) {
					if (i<vertexes-1 && j<vertexes-1) {
						aux[i][j] = adjacency[i][j];
					} else {
						aux[i][j] = false;
					}
				}
			}
		}
		adjacency = aux;
	}
	public void rmEdge(T e, T f) {
		//Check that elements E and F are in the graph
		if (table.getHash(e) != null && table.getHash(f) != null) {
			int v = table.getHash(e).getValue();
			int w = table.getHash(f).getValue();
			adjacency[v][w] = false;
			adjacency[w][v] = false;
			--edges;
		}
	}
	public void rmVertex(T elem) {
		//Remove element if hash is found
		try {
		if (table.getHash(elem) != null) {
			table.remove(table.getHash(elem));
			--vertexes;	
			//Decrease indexes of the elements located after the deleted one
			Node<Hash<T>> it = table.head();
			int k = table.getHash(elem).getValue();
			while (it != null) {
				if (k != it.getValue().getValue()) {
					it.getValue().decreaseValue();
				}
				it = it.getNext();
			}
			//Redimensionate adj matrix 
			boolean[][] aux = new boolean[vertexes][vertexes];
			if (aux.length != 0) {
				for (int i=0; i<vertexes; i++) {
					for (int j=0; j<vertexes; j++) {
						if (i<k && j<k) {
							aux[i][j] = adjacency[i][j];
						} else if (i<k && j>=k) {
							aux[i][j] = adjacency[i][j+1];
						} else if (i>=k && j<k) {
							aux[i][j] = adjacency[i+1][j];
						} else if (i>=k && j>=k) {
							aux[i][j] = adjacency[i+1][j+1];
						}
					}
				}
			}
			adjacency = aux;
		}
		} catch (EmptyCollectionEx e){
			System.out.println("Element not found");
		}
	}
	
	public LinkedList<T> shortestPath(T e, T f) {
		//BFS algorithm implementation
        // Check if both vertexes are in the graph
        if (table.getHash(e) == null || table.getHash(f) == null) {
            return new LinkedList<>(); // Return an empty path if some vertex is missing
        }
        Stack<T> st = new Stack<>(); // Track of BFS traversal, simulates recursion,
        							//it is effective as Graph implementation is static
        LinkedList<T> visited = new LinkedList<>(); // Note down visited nodes
        LinkedList<T> path = new LinkedList<>(); // Store the reconstructed path
        LinkedList<T> parent = new LinkedList<>(); // Store parent relationships
        // Initialize parent list with null values
        for (int i = 0; i < vertexes; i++) {
            parent.insert(null,parent.size()); 
        }
        // Start BFS traversing with e
        st.push(e); //beginning of the track
        visited.insert(e, visited.size()); //set e as visited
        //Begin with traversing
        boolean found = false; 
        try {
        while (!st.isEmpty() && !found) {
        	//Check that tracking stack is finally empty and f is found
            T current = st.peek(); 
            st.pop(); // Dequeue the current vertex
            // Get the index of the current vertex
            int i = table.getHash(current).getValue();
            // Explore neighbours of the current vertex
            for (int j = 0; j < vertexes; j++) {
                if (adjacency[i][j]) { // Check if e and f are neighbours or 
                						//if a friend of e is neighbour of f too
                    T neighbour = table.getHash(j).getKey(); 
                    // Get the vertex corresponding to index i
                    //Check that the vertex has not been visited yet
                    if (!visited.contains(neighbour)) {
                        visited.insert(neighbour, visited.size()); //set nghbr as visited
                        st.push(neighbour); //push to track as a potential possibility
                        					//of belonging to the track
                        parent.setElement(j, current); // Set the parent of this neighbour
                        // Stop if we reach f
                        if (neighbour.equals(f)) {
                            found = true;
                            break;
                        }
                    }
                }
            }
        }
        } catch (EmptyCollectionEx ex) {
        	System.out.println(ex.getStackTrace());
        }

        // Reconstruct the path from end to start using the parent list
        if (found) {
            T step = f;
            try {
            while (step != null) {
                path.insert(step, 0); // Add to the path in reverse order
                step = parent.getElement(table.getHash(step).getValue());
                //next element to add to the list is the parent of 'step'
            }
            } catch (EmptyCollectionEx ex) {
            	System.out.println(ex.getStackTrace());
            }
        }
        return path; // Return the shortest path
    }
	
	public LinkedList<T> largestPath(T e, T f) {
		//Front-end method
		// Backtracking implementation
        // Check if both vertexes are in the graph
        if (table.getHash(e) == null || table.getHash(f) == null) {
            return new LinkedList<>(); // Return an empty path if some vertex is missing
        }
        //If both vertexes are in the graph, then check every possible path that the graph has
        Hash<T> h1 = table.getHash(e);
        int origin = h1.getValue();
        Hash<T> h2 = table.getHash(f);
        int destiny = h2.getValue();
        LinkedList<T> visited = new LinkedList<>(); // Note down visited nodes
        LinkedList<T> path = new LinkedList<>(); // Store the current path
        LinkedList<LinkedList<T>> all; //all paths stored in a list
        all = allPaths(origin, destiny, visited, path);
        //Catch the largest one
        try {
        int max = all.getElement(0).size();
        for (int i=1; i<all.size(); i++) {
        	if (all.getElement(i).size() > max) {
        		max = all.getElement(i).size();
        	}
        }
        return all.getElement(max);
        } catch (EmptyCollectionEx ex) {
        	System.out.println(ex.getStackTrace());
        	return new LinkedList<>();
        }
	}
	
	private LinkedList<LinkedList<T>> allPaths(int origin, int destiny,
											LinkedList<T> visited, LinkedList<T> path){
		//Worker method, uses recursion to traverse every possible path
		LinkedList<LinkedList<T>> result = new LinkedList<>(); //all paths stored in a list
		visited.insert(table.getHash(origin).getKey(), visited.size()); //set origin as visited
		path.insert(table.getHash(origin).getKey(), path.size()); //add origin to the path
		if (origin == destiny) {
			//If both vertexes match, the path between both has been found, 
			//so we can finally add it to the result and break the recursion
			result.insert(path, result.size());
		} else {
			//Check recursively every neighbour of the origin vertex
			for (int j = 0; j < vertexes; j++) {
				if (adjacency[origin][j] == true && 
						!visited.contains(table.getHash(j).getKey())) {
					allPaths(j, destiny, visited, path);
				}
			}
		}
		try {
		//Unmark the current node, so next recursions could perform this vertex
		//for the traversing, which means, take a step behind
		visited.remove(table.getHash(origin).getKey()); 
		path.remove(table.getHash(origin).getKey()); //remove current node from the path
		} catch (EmptyCollectionEx ex) {
        	System.out.println(ex.getStackTrace());
        }
		return result;
	}
}
