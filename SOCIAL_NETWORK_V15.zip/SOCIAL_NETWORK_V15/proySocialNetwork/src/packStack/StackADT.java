package packStack;

import packEx.*;

public interface StackADT<T> {
		public void push (T element);
		public void pop() throws EmptyCollectionEx;
		public T peek() throws EmptyCollectionEx;
		public boolean isEmpty();
		public int size();
}
