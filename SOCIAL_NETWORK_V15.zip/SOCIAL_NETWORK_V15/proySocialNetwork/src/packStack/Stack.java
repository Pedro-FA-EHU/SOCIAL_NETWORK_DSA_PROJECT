package packStack;

import packEx.*;
import packList.Node;

public class Stack<T> implements StackADT<T>{
	protected int size;
	protected Node<T> sp;
	
	  public Stack (){
	    size = 0;
	    sp = null;
	  }

	  public void push (T elem){
		Node<T> node = new Node (elem);
		node.setNext(sp);
		sp = node;
	    size++;
	  }

	  public void pop() throws EmptyCollectionEx{
	    if (isEmpty())
	      throw new EmptyCollectionEx("Stack");
	    --size;
	    Node<T> aux = sp.getNext();
	    sp.setNext(null);
	    sp = aux;
	  }
	   
	  public T peek() throws EmptyCollectionEx{
	    if (isEmpty())
	      throw new EmptyCollectionEx("Stack");
	    return sp.getValue();
	  }

	  //isEmpty: stack[T] -> boolean
		//isEmpty(new) = true
		//isEmpty(push(x,s)) = false
	  public boolean isEmpty() {
	    return (size == 0);
	  }
	 
	  public int size() {
	    return size;
	  }
	  
}
