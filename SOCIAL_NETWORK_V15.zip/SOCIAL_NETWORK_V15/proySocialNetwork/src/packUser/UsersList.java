package packUser;

import java.util.Arrays;
import packComparators.*;
import packList.*;
import packEx.*;

public class UsersList extends LinkedList<Person>{
	//Constructor
	public UsersList () {
		super();
	}
	//Our own methods
	public boolean repeatedID(String s) throws ExistingIDEx{
		boolean repeated=false;
		int j=0;
		while(!repeated && j<size()) {
			try {
			if(getElement(j).getId().equals(s)) {
				repeated=true;
				throw new ExistingIDEx();
			}
			else {
				j++;
			}
			} catch(IndexOutOfBoundsException e) {
				System.out.println(e.getMessage());
			} catch(EmptyCollectionEx e) {
				System.out.println(e.getMessage());
			}
		}
		return repeated;
	}

	public Person search (String id) {
		Person p = null;
		try {
			boolean userFound = false;
			int i=0;
			while(!userFound && i<size()) {
				if(getElement(i).getId().equals(id)) {
					userFound=true;
				    p = getElement(i);
				}
				i++;
			}
			// if(!userFound) return initial null value
		} catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		} catch(EmptyCollectionEx e) {
			System.out.println(e.getMessage());
		} 
		return p;
	}
	public UsersList searchBySurname (String surname) {
		UsersList result = new UsersList();
		try {
			int i=0;
			while(i<size()) {
				if(getElement(i).getSurname().equals(surname)) {
					//Insert in order
				    result.insert(getElement(i), result.size());
				}
				i++;
			}
			// if(!userFound) return initial null value
		} catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		} catch(EmptyCollectionEx e) {
			System.out.println(e.getMessage());
		} 
		return result;
	}
	
	public void print() {
		try {
			for(int i=0;i<size();i++) {
				System.out.println(getElement(i).toString());
			}
		} catch(EmptyCollectionEx e) {
			System.out.println("There is no Users in the Network.");
		} catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void sort() { //Bubble Sort
		Person aux;
		UserChainedComparator comparator = new UserChainedComparator(
				new UserBirthplaceComparator(), new UserNameComparator(), new UserSurnameComparator());
		for (int i=size()-1; i>=0; --i) {
			//Ordered elements are moved to the rear
			//Bubble pairs
			for (int j=0; j<i; j++) {
				try {
				if (comparator.compare(getElement(j), getElement(j+1)) > 0) { 
					//Swap
                    aux = getElement(j);
                    setElement(j, getElement(j + 1));
                    setElement(j + 1, aux);
				}
				} catch (IndexOutOfBoundsException e) {
					e.printStackTrace();
				} catch (EmptyCollectionEx e) {
					e.printStackTrace();
				}
			}
		}
	}
}
