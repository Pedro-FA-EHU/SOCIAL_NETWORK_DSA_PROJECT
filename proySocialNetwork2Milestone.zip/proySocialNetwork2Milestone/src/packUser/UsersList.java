package packUser;

import java.util.Arrays;


import packComparators.*;
import packList.*;
import packEx.*;

public class UsersList extends LinkedList<Person>{
	//Constructor
	public UsersList () {
		super();
	}
	//Our own methods
	public boolean repeatedID(String s) throws ExistingIDEx{
		boolean repeated=false;
		int j=0;
		while(!repeated && j<size()) {
			try {
			if(getElement(j).getId().equals(s)) {
				repeated=true;
				throw new ExistingIDEx();
			}
			else {
				j++;
			}
			} catch(IndexOutOfBoundsException e) {
				System.out.println(e.getMessage());
			} catch(EmptyCollectionEx e) {
				System.out.println(e.getMessage());
			}
		}
		return repeated;
	}
	public void loadPerson(String user) {
		//We expect the client introduces the user information as expected in the
		//project specifications
		//idperson,name,lastname,birthdate,gender,birthplace,
		//home,studiedat;workplaces;films;groupcode
		
		// RA -> Repeatable Attributes (studiedat,workplaces,films)
		// URA -> Unrepeatable Attributes (idperson,name,lastname,...,groupcode)
		
		String[] personArrayRA=user.split(";");
		String[] personArrayURA= personArrayRA[0].split(",");	
		
		try {
			String id = personArrayURA[0];
			String name = personArrayURA[1];
			String lastname = personArrayURA[2];
			String birthdate = personArrayURA[3];
			String gender = personArrayURA[4];
			String birthplace = personArrayURA[5];
			//In our app, date format is DD-MM-YY
			String[] date = birthdate.split("-");
			String home = personArrayURA[6];
			String[] studiedat = Arrays.copyOfRange(personArrayURA, 7, 
					personArrayURA.length);
			String[] workplaces = personArrayRA[1].split(",");
			String[] films = personArrayRA[2].split(",");
			
			// Just in case, ... ;G6,asdas,asdasd,asdasd,... (Incorrect Structure of User Information)
			String groupcode = personArrayRA[3].split(",")[0];
			if( repeatedID(id)==false ) {
				
				Person s = new Person(id, name, lastname, 
						birthdate, gender, birthplace, 
						home, studiedat, workplaces, films, groupcode);
				//Insert in order
				insert(s,size()-1);

			}
		} catch(ExistingIDEx e) {
			System.out.println(e.getMessage());
			System.out.println("Please, introduce another ID. "+ personArrayURA[0] + " not valid.");
		} catch(EmptyIDEx e) {
			System.out.println(e.getMessage());
			System.out.println("Please, introduce an ID.");
		} catch(IndexOutOfBoundsException e) {
			//IndexOutOfBoundsException handles ArrayIndexOutOfBoundsException too
			System.out.println("Please enter user information " +
					  personArrayURA[0] + " in the correct structure way.");
		}
	}
	public Person search (String id) {
		Person p = null;
		try {
			boolean userFound = false;
			int i=0;
			while(!userFound && i<size()) {
				if(getElement(i).getId().equals(id)) {
					userFound=true;
				    p = getElement(i);
				}
				i++;
			}
			// if(!userFound) return initial null value
		} catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		} catch(EmptyCollectionEx e) {
			System.out.println(e.getMessage());
		} 
		return p;
	}
	public UsersList searchBySurname (String surname) {
		UsersList result = new UsersList();
		try {
			int i=0;
			while(i<size()) {
				if(getElement(i).getSurname().equals(surname)) {
					//Insert in order
				    result.insert(getElement(i), result.size());
				}
				i++;
			}
			// if(!userFound) return initial null value
		} catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		} catch(EmptyCollectionEx e) {
			System.out.println(e.getMessage());
		} 
		return result;
	}
	public void sort() { //Bubble Sort
		Person aux;
		UserChainedComparator comparator = new UserChainedComparator(
				new UserBirthplaceComparator(), new UserNameComparator(), new UserSurnameComparator());
		for (int i=size()-1; i>=0; --i) {
			//Ordered elements are moved to the rear
			//Bubble pairs
			for (int j=0; j<i; j++) {
				try {
				if (comparator.compare(getElement(j), getElement(j+1)) > 0) { 
					//Swap
                    aux = getElement(j);
                    setElement(j, getElement(j + 1));
                    setElement(j + 1, aux);
				}
				} catch (IndexOutOfBoundsException e) {
					e.printStackTrace();
				} catch (EmptyCollectionEx e) {
					e.printStackTrace();
				}
			}
		}
	}
}
