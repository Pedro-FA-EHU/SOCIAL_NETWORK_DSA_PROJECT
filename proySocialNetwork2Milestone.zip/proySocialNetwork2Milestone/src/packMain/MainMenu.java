package packMain;
import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.filechooser.*;

import packUser.*;
import packEx.*;
import packList.*;

public class MainMenu {
	private static UsersList usersList = new UsersList();
	private static Scanner input = new Scanner(System.in);
	private static boolean programEnable = true; //prevent log out
	private static boolean taskExecuted; //control that the task asked is
										//completely executed
	
	public static String fileChooser() {
		JFileChooser jfc = new JFileChooser
				(FileSystemView.getFileSystemView().getHomeDirectory());
		int returnValue = jfc.showOpenDialog(null);
		String path = null;
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			File selectedFile = jfc.getSelectedFile();
		     path = selectedFile.getAbsolutePath();
		}
		return path;
	}
	
	public static void loadUsers(String path) {
		String myPath = path;
			try{
				File myFilename = new File(myPath);
				Scanner input2Program = new Scanner (myFilename);
				// First line of people.txt is not useful, it is a header. Go to next line
				String oneUser=input2Program.nextLine();
				while ( input2Program.hasNext() ){	
					oneUser = input2Program.nextLine();
					usersList.loadPerson(oneUser);
				}
			} catch ( FileNotFoundException e) {
					 e.printStackTrace();
					 System.out.println("Error, file not found");
					 System.out.println("Task aborted");
			}
			catch(NullPointerException e) {
				System.out.println("Introduce a file, please");
			}
	}
	
	public static void insertDoubleFriendship(String[] friendships) throws UnregisteredIDEx {
	    int i = 0;
	    boolean friendFound1 = false;
	    boolean friendFound2 = false;

	    while (!friendFound1) {
	        try {
	            if (usersList.getElement(i).getId().equals(friendships[0])) {
	                friendFound1 = true;
	                usersList.getElement(i).getFriendships()
	                .insert(friendships[1], usersList.getElement(i).getFriendships().size()-1);
	            }
	        } catch (EmptyCollectionEx e) {
	            System.out.println(e.getMessage());
	        } catch (IndexOutOfBoundsException e) {
	            System.out.println(e.getMessage());
	        }
	        i++;
	    }	
		i=0;
		 while (!friendFound2) {
		      try {
		         if (usersList.getElement(i).getId().equals(friendships[1])) {
		               friendFound2 = true;
		               usersList.getElement(i).getFriendships()
		                .insert(friendships[0], usersList.getElement(i).getFriendships().size()-1);
		            }
		        } catch (EmptyCollectionEx e) {
		            System.out.println(e.getMessage());
		        } catch (IndexOutOfBoundsException e) {
		            System.out.println(e.getMessage());
		        }
		        i++;
		    }
		}
	
	public static void loadFriend (String f) throws UnregisteredIDEx {
		String[] friendships=f.split(",");
		boolean friendFound=false;
		int i=0;
		while(!friendFound && i<usersList.size()) {
			try {
				if(usersList.getElement(i).getId().equals(friendships[0])) {
					friendFound=true;
					insertDoubleFriendship(friendships);
				} else {
					i++;
				}
			} catch(EmptyCollectionEx e) {
				System.out.println(e.getMessage());
			} catch(IndexOutOfBoundsException e) {
				System.out.println(e.getMessage());
			} catch(UnregisteredIDEx e) {
				System.out.println(e.getMessage());
			}
		}
		if(i==usersList.size() && !friendFound) {
			throw new UnregisteredIDEx();
		}
		
		
		
		
		
	}
	
	public static void loadFriendships(String path) {
		String myPath = path;
			try{
				File myFilename = new File(myPath);
				Scanner input2Program = new Scanner (myFilename);
				String oneFriendship=input2Program.nextLine();
				while ( input2Program.hasNext() ){		
					oneFriendship = input2Program.nextLine();
					loadFriend(oneFriendship);			
				}
			} catch (FileNotFoundException e) {
					 e.printStackTrace();
					 System.out.println("Error, file not found");
			} catch (UnregisteredIDEx e) {
				System.out.println(e.getMessage());
			}
			catch(NullPointerException e) {
				System.out.println("Introduce a file, please");
			}
	}

	public static void removeAllUserFriendships(Person s) {	
		boolean userFriendFound=false;
		int j=0;
		for(int i=0;i<s.getFriendships().size();i++) {
			while(!userFriendFound) {
				try {
					if(usersList.getElement(j).getId().equals(s.getFriendships().getElement(i))) {
						userFriendFound=true;
						usersList.getElement(j).getFriendships().remove(s.getId());
					}
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				j++;
			}
			userFriendFound=false;
			j=0;
		}
	}
	
	
	public static void printUsers() {
		try {
			for(int i=0;i<usersList.size();i++) {
				System.out.println(usersList.getElement(i).toString());
			}
		} catch(EmptyCollectionEx e) {
			System.out.println("There is no Users in the Network.");
		} catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void printFriendships() {
		try {
			for(int i=0;i<usersList.size();i++) {
				System.out.println(usersList.getElement(i).getId()+" --> "
						+usersList.getElement(i).getFriendshipsString());
			}
		} catch(EmptyCollectionEx e) {
			System.out.println(e.getMessage());
		} catch(IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void printResidentials(Person p) {
		// Problematica de que residentes se vayan a encontrar repetidos
			System.out.println("People who live in the same hometown with "+p.getId()+" :");
			for(int i=0;i<usersList.size();i++) {
				try {
					if(!usersList.getElement(i).getId().equals(p.getId()) && usersList.getElement(i).getHome().equals(p.getHome())&&!p.getHome().equals("")) {
						System.out.println(usersList.getElement(i).getId()+" : "+usersList.getElement(i).getName()+", "+usersList.getElement(i).getSurname()+", "+usersList.getElement(i).getBirthplace()+"|| "+usersList.getElement(i).getStudiedat());
					}
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
			}
		
			System.out.println("");
			System.out.println("People who were born in the same Hometown where "+p.getId()+" lives"+" :");
			for(int i=0;i<usersList.size();i++) {
				try {
					if(!usersList.getElement(i).getId().equals(p.getId()) && usersList.getElement(i).getBirthplace().equals(p.getHome())&&!p.getHome().equals("")) {
						System.out.println(usersList.getElement(i).getId()+" : "+usersList.getElement(i).getName()+", "+usersList.getElement(i).getSurname()+", "+usersList.getElement(i).getBirthplace()+"|| "+usersList.getElement(i).getStudiedat());
					}
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
		
			}
			
			System.out.println("----------------------------------------------------");
		
			
	}
	
	public static void loadResidents(String path) {
		String myPath = path;
		try{
			File myFilename = new File(myPath);
			String resident;
			Scanner input2Program = new Scanner (myFilename);
			while ( input2Program.hasNext() ){		
				resident=input2Program.next();
				Person p=usersList.search(resident);
				if(p!=null) {
					printResidentials(p);
				}
			}
		} catch (FileNotFoundException e) {
				 //e.printStackTrace();
				 System.out.println("Error, file not found");
		} 
		catch(NullPointerException e) {
			System.out.println("Introduce a file, please");
		}
	}
	
	public static void printMenuOptions() {
        System.out.println("");
        //First milestone
        System.out.println("1. Load Users to the Network");
        System.out.println("2. Load Users' Friendships");
        System.out.println("3. Print Users' Information");
        System.out.println("4. Print Users' Friendships");
        System.out.println("5. Load user to Database");
        System.out.println("6. Delete user to Database");
        //Second milestone
        System.out.println("7. Friends of a user given surname");
        System.out.println("8. List of people born in a city");
        System.out.println("9. List of people born between two years,"
        		+ "sorted by birthplace, surname and name");
        System.out.println("10. Print Users who were born and live in the same Hometown");
        System.out.println("11. Split users into classes of the same movie favourites");
        System.out.println("0. Log out");
        System.out.println("");	
	}
	
	
	
	
	public static void taskSelect() {
		int key;
		try {
			key = input.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("System Error, type expected was KEY NUMBER");
			input.nextLine();
			key = -1; //sentinel needed for executing else block due to mismatch
		} 
		if (key==0) {
			// Log out
			programEnable = false;
			input.close();
		} else if (key==1) {
			//Load people into the network loadUsers()
			System.out.println("Introduce users list's path to load : ");
			String path = fileChooser();
			loadUsers(path);
		} else if (key==2) {				
			//Load user's cliques loadFriendships()
			System.out.println("Introduce friendships list's path to load : ");
			String path = fileChooser();
			loadFriendships(path);
		} else if (key==3) {
			//Print out people printUsers()
			printUsers();
		} else if (key==4) {
			//Print out cliques printFriendships()
			printFriendships();
		} else if (key==5) {
			//Insert user loadPerson()
			System.out.println("Introduce user information to load : ");
			String user = input.next();
			usersList.loadPerson(user);
		} else if (key==6) {
			//Delete user remove()
			System.out.println("Introduce user ID to remove : ");
			String id = input.next();
			Person user;
			try {
				user = usersList.search(id);
				if (user!=null) {
					usersList.remove(user);
					removeAllUserFriendships(user);
				} 
			} catch(EmptyCollectionEx e) {
				System.out.println(e.getMessage());
			} 
		} else if (key == 7) {
			//Friends of a user given a surname
			System.out.println("Introduce surname of a Person : ");
			String username=input.next();
			int i=0;
			boolean found=false;
			while(i<usersList.size()) {
				try {
					if(usersList.getElement(i).getSurname().equals(username)) {
						System.out.println(usersList.getElement(i).getId()+": "+usersList.getElement(i).getFriendshipsString());
						found=true;
					}
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				i++;
			}
			if(i==usersList.size() && found==false) {
				System.out.println("There is no with username "+username);
			}
		} else if (key == 8) {
			// Given a city returns people who were born there.
			System.out.println("Introduce birthplace : ");
			String city=input.next();
			boolean found=false;
			int i=0;
			while(i<usersList.size()) {
				try {
				if(usersList.getElement(i).getBirthplace().equals(city)) {
					found=true;
					System.out.println("ID : "+usersList.getElement(i).getId()+" || "+
					"Surname : "+usersList.getElement(i).getSurname());
				}
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				i++;
			}
			
			if(i==usersList.size() && found==false) {
				System.out.println("There is no users born in "+city);
			}			
		} else if (key == 9) {
			//List of people born between two years, sorted by birthplace, surname and name
			System.out.println("Introduce initial year: ");
			int y1 = input.nextInt();
			System.out.println("Introduce final year: ");
			int y2 = input.nextInt();
			if (y1 <= y2) {
				UsersList aux = new UsersList();
				for (int i=0; i<usersList.size(); i++) {
					try {
					if ((usersList.getElement(i).getBirthdate().getYear()>=y1) &&
						(usersList.getElement(i).getBirthdate().getYear()<=y2)) {
							aux.insert(usersList.getElement(i), aux.size());
					}
					} catch (IndexOutOfBoundsException e) {
						e.printStackTrace();
					} catch (EmptyCollectionEx e) {
						e.printStackTrace();
					}
				}
				aux.sort();
				System.out.println("Task accomplished, list sorted");
				System.out.println("");
				//Print list
				for (int i=0; i<aux.size(); i++) {
					try {
						System.out.println(aux.getElement(i).toString());
					} catch (IndexOutOfBoundsException e) {
						e.printStackTrace();
					} catch (EmptyCollectionEx e) {
						e.printStackTrace();
					}
				}
			} else {
				System.out.println("Fatal error, final year is smaller than initial year");
			}
		} else if (key == 10) {
			System.out.println("Introduce residentials path to load : ");
			System.out.println("----------------------------------------------------");
			String path = fileChooser();
			loadResidents(path);
		} else if (key == 11) {
			// Split users into classes of the same movie favourites.
			LinkedList <Profile> L=new LinkedList();
			// Generate base List
			for(int i=0;i<usersList.size();i++) {
				Profile pr;
				Person p;
				try {
					p=usersList.getElement(i);
					pr=new Profile(p.getMovies(),p);
					L.insert(pr, L.size()-1);
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
			}

			// Grouping in each of the possible groups of different movies
			int i=0;
			int j=1;
			boolean removed=false;

			while(i<L.size()) {
				while(j<L.size()) {
					try {
						if(L.getElement(j).equals(L.getElement(i))) {
							L.getElement(i).setUserMoviesFavourites(L.getElement(j).getPerson());
							L.remove(L.getElement(j));
							removed=true;
						}
						
					}
					catch(IndexOutOfBoundsException e) {
						System.out.println(e.getMessage());
					}
					catch(EmptyCollectionEx e) {
						System.out.println(e.getMessage());
					}
					
					if (!removed) {
						j++;
					}
					removed=false;
				}
				i++;
				j=i+1;
			}
			for(int k=0;k<L.size();k++) {
				try {
					System.out.println("Group #"+k+" :"+L.getElement(k).getName());
					for(int z=0;z<L.getElement(k).getUserFavouriteMovies().size();z++) {
						System.out.println(L.getElement(k).getUserFavouriteMovies().getElement(z).getId());
					}
					System.out.println(".............................................................................................................");
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
			}
						
		} else {
			//Others. Insert another number, run exception
			System.out.println("System Error, introduce a valid option key number");
			System.out.println();			
		}
		taskExecuted = true;
		//System.out.println("Task succesfully accomplished");
		System.out.println();
		if (key!=0) {
			System.out.println("------------------------------");
	        System.out.println("******************************");
			printMenuOptions();
		}
	}
	
	public static void main(String[] args) {
        System.out.println("------------------------------");
        System.out.println("******************************");
        System.out.println("Welcome to the main menu!");
        printMenuOptions();
        System.out.println("******************************");
        System.out.println("------------------------------");
		while (programEnable) {
			taskExecuted = false;
			taskSelect();
			while (!taskExecuted) {
				; //do nothing, let the work done by the taskSelect subprogram
				//when this method ends its task, we'll apply again for another key int.
			}
		}
		//programEnable is false within this line
		System.out.println("Logged out succesfully");
		System.out.println("Come back soon!");
	}
}
