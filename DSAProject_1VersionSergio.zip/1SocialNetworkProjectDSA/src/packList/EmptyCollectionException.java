package packList;

/*This exception is thrown when we want to perform some illegal operation
on a empty collection */
public class EmptyCollectionException extends Exception{
	public EmptyCollectionException() {
		super("Empty Collection");
	}
	public EmptyCollectionException(String message) {
		super(message);
	}
}

