package packList;


public interface ListADT<T>{
	public void insert (T element, int pos) throws AccessOutOfBoundariesException;
	public T getElement (int pos) throws AccessOutOfBoundariesException, EmptyCollectionException;
	public int getPosition (T element) throws EmptyCollectionException;
	public void remove (T element) throws EmptyCollectionException;
	public T getHead() throws EmptyCollectionException;
	public T getTail() throws EmptyCollectionException;
	public boolean contains (T element);
	public boolean isEmpty();
	public int size ();
	public String toString();
}

