package packUser;

public class ExistingIDException extends Exception {
	public ExistingIDException() {
		super("Already existing ID. Please change it.");
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
