package packUser;

public class EmptyIDException extends Exception{
	public EmptyIDException() {
		super("ID is compulsory.");
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
