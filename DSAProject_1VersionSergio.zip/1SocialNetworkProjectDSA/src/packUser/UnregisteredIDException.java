package packUser;

public class UnregisteredIDException extends Exception{
	public UnregisteredIDException() {
		super("No person registered on the social network with this ID has been found.");
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
