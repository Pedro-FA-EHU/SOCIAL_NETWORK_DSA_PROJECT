package packMain;

import packUser.*;


import packList.*;



import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

import java.util.InputMismatchException;
import java.util.Arrays;

public class MainMenu {
	private static Scanner input = new Scanner(System.in);
	private static boolean programEnable = true;
	private static LinkedList<Person> userList=new LinkedList();
	
		
	
	
	public static boolean repeatedID(String s) throws ExistingIDException{
		boolean repeated=false;
		int j=0;

		while(!repeated && j<userList.size()) {
			try {
			if(userList.getElement(j).getId().equals(s)) {
				repeated=true;
				throw new ExistingIDException();
			}
			else {
				j++;
			}
			}
			catch(AccessOutOfBoundariesException e) {
				System.out.println(e.getMessage());
			}
			catch(EmptyCollectionException e) {
				System.out.println(e.getMessage());
			}
		}
	
		return repeated;
	}
	

	
	
	public static void loadPerson(String user) {
		// RA -> Repeteable Atributes (studiedat,workplaces,films)
		// URA -> Unrepeteable Atributes (idperson,name,lastname,...,groupcode)
		
		
		String[] personArrayRA=user.split(";");
		String[] personArrayURA= personArrayRA[0].split(",");	
		
		String[] studiedat;
		studiedat=Arrays.copyOfRange(personArrayURA,7, personArrayURA.length);
		try {
		if( repeatedID(personArrayURA[0])==false ) {
			Person s=new Person(personArrayURA[0],personArrayURA[1],personArrayURA[2],personArrayURA[3],personArrayURA[4],personArrayURA[5],personArrayURA[6],studiedat,personArrayRA[1].split(","),personArrayRA[2].split(","),personArrayRA[3]);
			userList.insert(s,userList.size()-1);
		
		}
		}
		
		catch(ExistingIDException e) {
			System.out.println(e.getMessage());
			System.out.println("Please, introduce another ID."+personArrayURA[0]+" not valid.");
		}
		
		catch(EmptyIDException e) {
			System.out.println(e.getMessage());
			System.out.println("Please, introduce an ID.");
		}
		catch( AccessOutOfBoundariesException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	
	

	public static void loadUsers() {
		
			try{
				System.out.println("Enter the file address : ");
				File myFilename = new File(input.nextLine());
				Scanner input2Program = new Scanner (myFilename);
				// First line of people.txt is not useful.
				String oneUser=input2Program.nextLine();
				while ( input2Program.hasNext() ){		
					oneUser = input2Program.nextLine();
					loadPerson(oneUser);
				}
			
			} catch ( FileNotFoundException e ) {
					 System.out.println("Error, file not found");
			}
	}
	
	public static void printUsers() {
		try {
		System.out.println("*****************");
		System.out.println("-----------------");
		for(int i=0;i<userList.size();i++) {
			System.out.println(userList.getElement(i).toString());
			}
		}
		catch(EmptyCollectionException e) {
			System.out.println("There is no Users in the Network.");
		}
		catch(AccessOutOfBoundariesException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("-----------------");
		System.out.println("*****************");

		
	}
	public static void insertDoubleFriendship(String[] friendships) throws UnregisteredIDException {
		
		int i=0;
		boolean friendFound1=false;
		boolean friendFound2=false;
		try {
		while(!friendFound1) {
			if(userList.getElement(i).getId().equals(friendships[0])) {
				friendFound1=true;
				if(userList.getElement(i).getFriendships().equals("")) {
					userList.getElement(i).setFriendships(friendships[1]);
				}
				else {
					userList.getElement(i).setFriendships(userList.getElement(i).getFriendships()+","+friendships[1]);
				}
				
			}
			else {
				i++;
			}
		}
		i=0;
		while(!friendFound2 && i<userList.size()) {
			if(userList.getElement(i).getId().equals(friendships[1])) {
				friendFound2=true;
				if(userList.getElement(i).getFriendships().equals("")) {
					userList.getElement(i).setFriendships(friendships[0]);
				}
				else {
					userList.getElement(i).setFriendships(userList.getElement(i).getFriendships()+","+friendships[0]);
				}
				
			}
			else {
				i++;
			}
		}
		}
		catch(EmptyCollectionException e) {
			System.out.println(e.getMessage());
		}
		catch(AccessOutOfBoundariesException e) {
			System.out.println(e.getMessage());
		}
		
		if(!friendFound2 && i==userList.size()) {
			throw new UnregisteredIDException();
		}
		
	}
	
	
	public static void loadFriend (String f) throws UnregisteredIDException {
		String[] friendships=f.split(",");
		boolean friendFound=false;
		int i=0;
		while(!friendFound && i<userList.size()) {
			try {
			if(userList.getElement(i).getId().equals(friendships[0])) {
				friendFound=true;
				insertDoubleFriendship(friendships);
			}
			else {
				i++;
	
			}
			}
			catch(EmptyCollectionException e) {
				System.out.println(e.getMessage());
			}
			catch(AccessOutOfBoundariesException e) {
				System.out.println(e.getMessage());
			}
			catch(UnregisteredIDException e) {
				System.out.println(e.getMessage());
			}
		}
		
		if(i==userList.size() && !friendFound) {
			throw new UnregisteredIDException();
		}
	}
	
	
	
	public static void loadFriendships() {
		
			try{
				System.out.println("Enter the file address : ");
				String myPath=input.nextLine();
				File myFilename = new File(myPath);
				Scanner input2Program = new Scanner (myFilename);
				String oneFriendship=input2Program.nextLine();
				while ( input2Program.hasNext() ){		
					oneFriendship = input2Program.nextLine();
					loadFriend(oneFriendship);
					
				}
			} catch (FileNotFoundException e) {
					 System.out.println("Error, file not found");
			}
			catch(UnregisteredIDException e) {
				System.out.println(e.getMessage());
			}
	
	}

	public static void printFriendships() {
		try {
			System.out.println("-----------------");
			System.out.println("*****************");
		for(int i=0;i<userList.size();i++) {
			System.out.println(userList.getElement(i).getId()+" --> "+userList.getElement(i).getFriendships());
		}
		System.out.println("*****************");
		System.out.println("-----------------");
		}
		catch(EmptyCollectionException e) {
			System.out.println(e.getMessage());
		}
		catch(AccessOutOfBoundariesException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	public static void removeUserFriendships(Person s) {
	    try {
	        boolean userFriendFound = false;
	        int j = 0;
	        for (int i = 0; i < s.getFriendships().split(",").length; i++) {
	            while (!userFriendFound && j < userList.size()) {
	                if (userList.getElement(j).getId().equals(s.getFriendships().split(",")[i])) {
	                    userFriendFound = true;
	                    userList.getElement(j).setFriendships(userList.getElement(j).getFriendships().replace(s.getId(), ""));
	                    // In case 2 comas
	                    userList.getElement(j).setFriendships(userList.getElement(j).getFriendships().replace(",,", ","));
	                    //In case the first	 letter of friendship atribute is coma
	                    if (userList.getElement(j).getFriendships().charAt(0) == ',') {
	                        userList.getElement(j).setFriendships(userList.getElement(j).getFriendships().substring(1));
	                    }
	                    //In case the last letter of friendship atribute is coma
	                    if (userList.getElement(j).getFriendships().charAt(userList.getElement(j).getFriendships().length() - 1) == ',') {
	                        userList.getElement(j).setFriendships(userList.getElement(j).getFriendships().substring(0, userList.getElement(j).getFriendships().length() - 1));
	                    }
	                } else {
	                    j++;
	                }
	            }
	            userFriendFound = false;
	            j = 0;

	        }
	    } catch (EmptyCollectionException e) {
	        System.out.println(e.getMessage());
	    } catch (AccessOutOfBoundariesException e) {
	        System.out.println(e.getMessage());
	    }
	    catch( StringIndexOutOfBoundsException e) {
	    	// Do nothing, just removeUser from the linkedList. Can happen in case, "friendship" Attribute remains empty.
	    }
	}

	public static void removeUser() {
		
		try {
		System.out.println("Introduce user ID to remove : ");
		String user=input.nextLine();
		boolean userFound=false;
		int i=0;
		while(!userFound && i<userList.size()) {
			if(userList.getElement(i).getId().equals(user)) {
				userFound=true;
				Person p=userList.getElement(i);
				userList.remove(p);
				removeUserFriendships(p);
			}
			else{
				i++;
			}
		}
		if(!userFound) {
			throw new UnregisteredIDException();
		}

		}
		catch(AccessOutOfBoundariesException e) {
			System.out.println(e.getMessage());
		}
		catch(EmptyCollectionException e) {
			System.out.println(e.getMessage());
		}
		catch(UnregisteredIDException e) {
			System.out.println(e.getMessage());
		}
	
	}
	
	public static void main(String[] args) {
        System.out.println("------------------------------");
        System.out.println("******************************");
        System.out.println("Welcome to the main menu!");
        System.out.println("");
        System.out.println("1. Load Users to the Network");
        System.out.println("2. Load Users' Friendships");
        System.out.println("3. Print Users' Information");
        System.out.println("4. Print Users' Friendships");
        System.out.println("5. Remove User");
        System.out.println("6. Log out");
        System.out.println("");
        System.out.println("******************************");
        System.out.println("------------------------------");

        while (programEnable) {
            System.out.print("Choose an option: ");
            try {
                int key = input.nextInt();
                input.nextLine(); // Clears after reading an int, just in case
                
                switch (key) {
                    case 1:
                        loadUsers();
                        break;
                    case 2:
                        loadFriendships();
                        break;
                    case 3:
                        printUsers();
                        break;
                    case 4:
                        printFriendships();
                        break;
                    case 5:
                        removeUser();
                        break;
                    case 6:
                        programEnable = false;
                        System.out.println("Logged out successfully");
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                input.nextLine(); // Clear the invalid input
            }
        }
        
        input.close();
    }
}
		
		
	
	
	
	
	
	

