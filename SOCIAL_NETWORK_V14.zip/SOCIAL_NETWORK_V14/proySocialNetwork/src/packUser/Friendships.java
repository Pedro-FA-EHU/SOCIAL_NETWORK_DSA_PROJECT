package packUser;
import packEx.EmptyCollectionEx;
import packEx.UnregisteredIDEx;
import packGraph.*;
import packHash.*;
import packList.LinkedList;

public class Friendships extends Graph<Person>{
	//Constructor
	public Friendships() {
		super();
	}
	//Own methods
	public void print() {
		int size = V();
		for(int i=0; i<size; i++) {
			Hash<Person> h1 = table.getHash(i);
			String p1 = h1.getKey().getId();
			System.out.print(p1 + " ====> ");
			for(int j=0; j<size; j++) {
				if (adjacency[i][j] == true) {
					Hash<Person> h2 = table.getHash(j);
					String p2 = h2.getKey().getId();
					System.out.print(p2 + ", ");					
				}
			}
			System.out.println();
		}
	}
	public void printFriendsOf(Person user) {
		int size = V();
		Hash<Person> h1 = table.getHash(user);
		int i = h1.getValue();
		for(int j=0; j<size; j++) {
			if (adjacency[i][j] == true) {
				Hash<Person> h2 = table.getHash(j);
				String p2 = h2.getKey().getId();
				System.out.print(p2 + ", ");					
			}
		}
		System.out.println();
	}
}
