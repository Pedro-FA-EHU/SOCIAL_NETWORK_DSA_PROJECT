package packHash;

import packList.*;

public class HashTable<T> extends LinkedList<Hash<T>>{
	//Constructor
	public HashTable(){
		super();
	}
	//Own methods
	public Hash<T> getHash(T elem){
		Hash<T> result = null; //sentinel value in case element T is not in the list
		//First case: Empty list
		if (size() == 0) {
			return null;
		//General case
		} else {
			Node<Hash<T>> aux = head();
			boolean found = false;
			int i = 0;
			while ((i < size()) && !found) {
				if (elem.equals(aux.getValue().getKey())) {
					found = true;
					result = aux.getValue();
				} else {
					aux = aux.getNext();
					i++;
				}
			}
			return result;
		}
	}
	public Hash<T> getHash(int index){
		Hash<T> result = null; //sentinel value in case element T is not in the list
		//First case: Empty list
		if (size() == 0) {
			return null;
		//General case
		} else {
			Node<Hash<T>> aux = head();
			boolean found = false;
			int i = 0;
			while ((i < size()) && !found) {
				if (index == aux.getValue().getValue()) {
					found = true;
					result = aux.getValue();
				} else {
					aux = aux.getNext();
					i++;
				}
			}
			return result;
		}
	}
}
