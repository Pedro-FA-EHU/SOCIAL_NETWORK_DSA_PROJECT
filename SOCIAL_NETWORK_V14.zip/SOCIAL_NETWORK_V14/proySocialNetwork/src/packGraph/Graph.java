package packGraph;

import packEx.*;
import packHash.*;
import packList.Node;

public class Graph<T> implements GraphADT<T>{
	//Static attributes
	protected HashTable<T> table;
	protected int vertexes;
	protected int edges;
	protected boolean[][] adjacency;
	//Constructor
	public Graph() { //Empty graph
		table = new HashTable<T>();
		vertexes = edges = 0;
		adjacency = new boolean[0][0]; //matrix of dimension 0x0
	}
	//Interface methods
	public int V() {
		return vertexes;
	}
	public int E() {
		return edges;
	}
	public void addEdge(T e, T f) {
		//Check that elements E and F are in the graph
		if (table.getHash(e) != null && table.getHash(f) != null) {
			int v = table.getHash(e).getValue();
			int w = table.getHash(f).getValue();
			adjacency[v][w] = true;
			adjacency[w][v] = true;
			edges++;
		}
	}
	public void addVertex(T elem) {
		//Create a Hash indexed according to the insertion order
		Hash<T> hash = new Hash<T>(elem, vertexes);
		table.insert(hash, vertexes);
		vertexes++;
		//Redimensionate adj matrix 
		boolean[][] aux = new boolean[vertexes][vertexes];
		if (aux.length == 1) {
			aux[0][0] = false;
		} else {
			for (int i=0; i<vertexes; i++) {
				for (int j=0; j<vertexes; j++) {
					if (i<vertexes-1 && j<vertexes-1) {
						aux[i][j] = adjacency[i][j];
					} else {
						aux[i][j] = false;
					}
				}
			}
		}
		adjacency = aux;
	}
	public void rmEdge(T e, T f) {
		//Check that elements E and F are in the graph
		if (table.getHash(e) != null && table.getHash(f) != null) {
			int v = table.getHash(e).getValue();
			int w = table.getHash(f).getValue();
			adjacency[v][w] = false;
			adjacency[w][v] = false;
			--edges;
		}
	}
	public void rmVertex(T elem) {
		//Remove element if hash is found
		try {
		if (table.getHash(elem) != null) {
			table.remove(table.getHash(elem));
			--vertexes;	
			//Decrease indexes of the elements located after the deleted one
			Node<Hash<T>> it = table.head();
			int k = table.getHash(elem).getValue();
			while (it != null) {
				if (k != it.getValue().getValue()) {
					it.getValue().decreaseValue();
				}
				it = it.getNext();
			}
			//Redimensionate adj matrix 
			boolean[][] aux = new boolean[vertexes][vertexes];
			if (aux.length != 0) {
				for (int i=0; i<vertexes; i++) {
					for (int j=0; j<vertexes; j++) {
						if (i<k && j<k) {
							aux[i][j] = adjacency[i][j];
						} else if (i<k && j>=k) {
							aux[i][j] = adjacency[i][j+1];
						} else if (i>=k && j<k) {
							aux[i][j] = adjacency[i+1][j];
						} else if (i>=k && j>=k) {
							aux[i][j] = adjacency[i+1][j+1];
						}
					}
				}
			}
			adjacency = aux;
		}
		} catch (EmptyCollectionEx e){
			System.out.println("Element not found");
		}
	}
}
