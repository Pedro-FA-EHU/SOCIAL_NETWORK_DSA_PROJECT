package packEx;

public class ExistingIDEx extends Exception{
	public ExistingIDEx() {
		super("Already existing ID. Please, change it.");
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
