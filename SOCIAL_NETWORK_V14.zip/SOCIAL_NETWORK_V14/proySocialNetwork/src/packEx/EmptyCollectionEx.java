package packEx;

public class EmptyCollectionEx extends Exception{
	public EmptyCollectionEx() {
		super();
	}
	public EmptyCollectionEx(String message) {
		super(message);
	}
}
