package packMain;
import java.io.*;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.filechooser.*;

import packUser.*;
import packEx.*;
import packList.*;

public class MainMenu {
	private static UsersList usersList = new UsersList();
	private static Friendships friendships = new Friendships();
	private static Scanner input = new Scanner(System.in);
	private static boolean programEnable = true; //prevent log out
	private static boolean taskExecuted; //control that the task asked is
										//completely executed
	
	public static String fileChooser() {
		JFileChooser jfc = new JFileChooser
				(FileSystemView.getFileSystemView().getHomeDirectory());
		int returnValue = jfc.showOpenDialog(null);
		String path = null;
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			File selectedFile = jfc.getSelectedFile();
		     path = selectedFile.getAbsolutePath();
		}
		return path;
	}
	
	public static void loadPerson(String user) {
		//We expect the client introduces the user information as expected in the
		//project specifications
		//idperson,name,lastname,birthdate,gender,birthplace,
		//home,studiedat;workplaces;films;groupcode
		
		// RA -> Repeatable Attributes (studiedat,workplaces,films)
		// URA -> Unrepeatable Attributes (idperson,name,lastname,...,groupcode)
		
		String[] personArrayRA=user.split(";");
		String[] personArrayURA= personArrayRA[0].split(",");	
		
		try {
			String id = personArrayURA[0];
			String name = personArrayURA[1];
			String lastname = personArrayURA[2];
			String birthdate = personArrayURA[3];
			String gender = personArrayURA[4];
			String birthplace = personArrayURA[5];
			//In our app, date format is DD-MM-YY
			String[] date = birthdate.split("-");
			String home = personArrayURA[6];
			String[] studiedat = Arrays.copyOfRange(personArrayURA, 7, 
					personArrayURA.length);
			String[] workplaces = personArrayRA[1].split(",");
			String[] films = personArrayRA[2].split(",");
			
			// Just in case, ... ;G6,asdas,asdasd,asdasd,... (Incorrect Structure of User Information)
			String groupcode = personArrayRA[3].split(",")[0];
			if(usersList.repeatedID(id)==false ) {
				Person s = new Person(id, name, lastname, 
						birthdate, gender, birthplace, 
						home, studiedat, workplaces, films, groupcode);
				//Insert in order
				usersList.insert(s,usersList.size()-1);
				//Insert person in the network (Friendships' graph)
				friendships.addVertex(s);
			}
		} catch(ExistingIDEx e) {
			System.out.println(e.getMessage());
			System.out.println("Please, introduce another ID. "+ personArrayURA[0] + " not valid.");
		} catch(EmptyIDEx e) {
			System.out.println(e.getMessage());
			System.out.println("Please, introduce an ID.");
		} catch(IndexOutOfBoundsException e) {
			//IndexOutOfBoundsException handles ArrayIndexOutOfBoundsException too
			System.out.println("Please enter user information " +
					  personArrayURA[0] + " in the correct structure way.");
		}
	}
	
	public static void loadUsers(String path) {
		String myPath = path;
			try{
				File myFilename = new File(myPath);
				Scanner input2Program = new Scanner (myFilename);
				// First line of people.txt is not useful, it is a header. Go to next line
				String oneUser=input2Program.nextLine();
				while ( input2Program.hasNext() ){	
					oneUser = input2Program.nextLine();
					loadPerson(oneUser);
				}
			} catch ( FileNotFoundException e) {
					 e.printStackTrace();
					 System.out.println("Error, file not found");
					 System.out.println("Task aborted");
			}
	}
	
	public static void loadFriendships(String path) {
		String myPath = path;
			try{
				File myFilename = new File(myPath);
				Scanner input2Program = new Scanner (myFilename);
				String oneFriendship=input2Program.nextLine();
				while ( input2Program.hasNext() ){		
					oneFriendship = input2Program.nextLine();
					String[] friendship = oneFriendship.split(",");
					Person p1 = usersList.search(friendship[0]);
					Person p2 = usersList.search(friendship[1]);
					if ( p1 != null && p2 != null) {
						//Assure that this function reads always two users already on the network
						friendships.addEdge(p1, p2);	
					}		
				}
			} catch (FileNotFoundException e) {
					 e.printStackTrace();
					 System.out.println("Error, file not found");
			}
	}
	
	
	
	public static void printResidentials(Person p) {
		// Problematica de que residentes se vayan a encontrar repetidos
			System.out.println("People who live in the same hometown with "+p.getId()+" :");
			for(int i=0;i<usersList.size();i++) {
				try {
					if(!usersList.getElement(i).getId().equals(p.getId()) && usersList.getElement(i).getHome().equals(p.getHome())&&!p.getHome().equals("")) {
						System.out.println(usersList.getElement(i).getId()+" : "+usersList.getElement(i).getName()+", "+usersList.getElement(i).getSurname()+", "+usersList.getElement(i).getBirthplace()+"|| "+usersList.getElement(i).getStudiedat());
					}
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
			}
		
			System.out.println("");
			System.out.println("People who were born in the same Hometown where "+p.getId()+" lives"+" :");
			for(int i=0;i<usersList.size();i++) {
				try {
					if(!usersList.getElement(i).getId().equals(p.getId()) && usersList.getElement(i).getBirthplace().equals(p.getHome())&&!p.getHome().equals("")) {
						System.out.println(usersList.getElement(i).getId()+" : "+usersList.getElement(i).getName()+", "+usersList.getElement(i).getSurname()+", "+usersList.getElement(i).getBirthplace()+"|| "+usersList.getElement(i).getStudiedat());
					}
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
			}
		System.out.println("----------------------------------------------------");		
	}
	
	public static void loadResidents(String path) {
		String myPath = path;
		try{
			File myFilename = new File(myPath);
			String resident;
			Scanner input2Program = new Scanner (myFilename);
			while ( input2Program.hasNext() ){		
				resident=input2Program.next();
				Person p=usersList.search(resident);
				if(p!=null) {
					printResidentials(p);
				}
			}
		} catch (FileNotFoundException e) {
				 //e.printStackTrace();
				 System.out.println("Error, file not found");
		} 
		catch(NullPointerException e) {
			System.out.println("Introduce a file, please");
		}
	}	
	
	public static void printMenuOptions() {
        System.out.println("");
        //First milestone
        System.out.println("1. Load Users to the Network");
        System.out.println("2. Load Users' Friendships");
        System.out.println("3. Print Users' Information");
        System.out.println("4. Print Users' Friendships");
        System.out.println("5. Load user to Database");
        System.out.println("6. Delete user to Database");
        //Second milestone
        System.out.println("7. Friends of a user given surname");
        System.out.println("8. List of people born in a city");
        System.out.println("9. List of people born between two years,"
        		+ "sorted by birthplace, surname and name");
        System.out.println("10. Find given a user's list people in the social media "
        		+ "who live or was born in the same city");
        System.out.println("11. Print profiles of users (by favourite movies)");
        System.out.println("0. Log out");
        System.out.println("");	
	}
	
	public static void taskSelect() {
		int key;
		try {
			key = input.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("System Error, type expected was KEY NUMBER");
			input.nextLine();
			key = -1; //sentinel needed for executing else block due to mismatch
		} 
		if (key==0) {
			// Log out
			programEnable = false;
			input.close();
		} else if (key==1) {
			//Load people into the network loadUsers()
			System.out.println("Introduce users list's path to load : ");
			String path = fileChooser();
			loadUsers(path);
		} else if (key==2) {				
			//Load user's cliques loadFriendships()
			System.out.println("Introduce friendships list's path to load : ");
			String path = fileChooser();
			loadFriendships(path);
		} else if (key==3) {
			//Print out people printUsers()
			usersList.print();
		} else if (key==4) {
			//Print out cliques printFriendships()
			friendships.print();
		} else if (key==5) {
			//Insert user loadPerson()
			System.out.println("Introduce user information to load : ");
			String user = input.next();
			loadPerson(user);
		} else if (key==6) {
			//Delete user remove()
			System.out.println("Introduce user ID to remove : ");
			String id = input.next();
			Person user;
			try {
				user = usersList.search(id);
				if (user!=null) {
					usersList.remove(user);
					friendships.rmVertex(user);
				} 
			} catch(EmptyCollectionEx e) {
				System.out.println(e.getMessage());
			} 
		} else if (key == 7) {
			//Friends of a user given a surname
			System.out.println("Introduce surname of a Person : ");
			String username=input.next();
			int i=0;
			boolean found=false;
			while(i<usersList.size()) {
				try {
					if(usersList.getElement(i).getSurname().equals(username)) {
						System.out.print(usersList.getElement(i).getId()+": ");
						friendships.printFriendsOf(usersList.getElement(i));		
						found=true;
					}
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				i++;
			}
			if(i==usersList.size() && found==false) {
				System.out.println("There is no with username "+username);
			}
		} else if (key == 8) {
			// Given a city returns people who were born there.
			System.out.println("Introduce birthplace : ");
			String city=input.next();
			boolean found=false;
			int i=0;
			while(i<usersList.size()) {
				try {
				if(usersList.getElement(i).getBirthplace().equals(city)) {
					found=true;
					System.out.println("ID : "+usersList.getElement(i).getId()+" || "+
					"Surname : "+usersList.getElement(i).getSurname());
				}
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
				i++;
			}
			// Para verificar si hay usuarios con ese birthplace
			if(i==usersList.size() && found==false) {
				System.out.println("There is no users born in "+city);
			}			
		} else if (key == 9) {
			//List of people born between two years, sorted by birthplace, surname and name
			System.out.println("Introduce initial year: ");
			int y1 = input.nextInt();
			System.out.println("Introduce final year: ");
			int y2 = input.nextInt();
			if (y1 <= y2) {
				UsersList aux = new UsersList();
				for (int i=0; i<usersList.size(); i++) {
					try {
					if ((usersList.getElement(i).getBirthdate().getYear()>=y1) &&
						(usersList.getElement(i).getBirthdate().getYear()<=y2)) {
							aux.insert(usersList.getElement(i), aux.size());
					}
					} catch (IndexOutOfBoundsException e) {
						e.printStackTrace();
					} catch (EmptyCollectionEx e) {
						e.printStackTrace();
					}
				}
				aux.sort();
				System.out.println("Task accomplished, list sorted");
				System.out.println("");
				//Print list
				for (int i=0; i<aux.size(); i++) {
					try {
						System.out.println(aux.getElement(i).toString());
					} catch (IndexOutOfBoundsException e) {
						e.printStackTrace();
					} catch (EmptyCollectionEx e) {
						e.printStackTrace();
					}
				}
			} else {
				System.out.println("Fatal error, final year is smaller than initial year");
			}
		} else if (key == 10) {
			// Load residentials.txt
			System.out.println("Introduce residentials path to load : ");
			System.out.println("----------------------------------------------------");
			String path = fileChooser();
			loadResidents(path);			
		} else if (key == 11) {
			// Split users into classes of the same movie favourites.
			LinkedList <Profile> L = new LinkedList();
			// Generate base List
			for(int i=0;i<usersList.size();i++) {
				Profile pr;
				Person p;
				try {
					p=usersList.getElement(i);
					pr=new Profile(p.getMovies(),p);
					L.insert(pr, L.size()-1);
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
			}
			// Grouping in each of the possible groups of different movies
			int i=0;
			int j=1;
			boolean removed=false;
			//SIZES??? SE VAN MODIFICANDO. SE SOLUCINA
			while(i<L.size()) {
				while(j<L.size()) {
					try {
						if(L.getElement(j).equals(L.getElement(i))) {
							L.getElement(i).setUserMoviesFavourites(L.getElement(j).getPerson());
							L.remove(L.getElement(j));
							removed=true;
						}	
					}
					catch(IndexOutOfBoundsException e) {
						System.out.println(e.getMessage());
					}
					catch(EmptyCollectionEx e) {
						System.out.println(e.getMessage());
					}
					if (!removed) {
						j++;
					}
					removed=false;
				}
				i++;
				j=i+1;	
			}
			for(int k=0;k<L.size();k++) {
				try {
					System.out.println("Group #"+k+" :"+L.getElement(k).getName());
					for(int z=0;z<L.getElement(k).getUserFavouriteMovies().size();z++) {
						System.out.println(L.getElement(k).getUserFavouriteMovies().getElement(z).getId());
					}
					System.out.println(".............................................................................................................");
				}
				catch(IndexOutOfBoundsException e) {
					System.out.println(e.getMessage());
				}
				catch(EmptyCollectionEx e) {
					System.out.println(e.getMessage());
				}
			}			
		} else if (key == 12) {
			//Shortest path between two users in the network
			
		} else {
			//Others. Insert another number, run exception
			System.out.println("System Error, introduce a valid option key number");
			System.out.println();			
		}
		taskExecuted = true;
		//System.out.println("Task succesfully accomplished");
		System.out.println();
		if (key!=0) {
			System.out.println("------------------------------");
	        System.out.println("******************************");
			printMenuOptions();
		}
	}
	
	public static void main(String[] args) {
        System.out.println("------------------------------");
        System.out.println("******************************");
        System.out.println("Welcome to the main menu!");
        printMenuOptions();
        System.out.println("******************************");
        System.out.println("------------------------------");
		while (programEnable) {
			taskExecuted = false;
			taskSelect();
			while (!taskExecuted) {
				; //do nothing, let the work done by the taskSelect subprogram
				//when this method ends its task, we'll apply again for another key int.
			}
		}
		//programEnable is false within this line
		System.out.println("Logged out succesfully");
		System.out.println("Come back soon!");
	}
}
