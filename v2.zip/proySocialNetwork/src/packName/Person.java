package packName;

public class Person {

	private String id;
	private String name;
	private String lastname;
	private String birthdate;
	private String gender;
	private String birthplace;
	private String home;
	private String[] studiedat;
	private String[] workplaces;
	private String[] films;
	private final String groupcode= "G612498";
	
	
	public Person(String pId,String pName,String pLastName,String pBirthDate,String pGender,String pBirthPlace, String pHome, String[] pStudieDat, String[] pWorkPlaces, String[] pFilms) {

		id=pId;
		name=pName;
		lastname=pLastName;
		birthdate=pBirthDate;
		gender=pGender;
		home=pHome;
		studiedat=pStudieDat;
		workplaces=pWorkPlaces;
		films=pFilms;
		
	}
	
	
	
	
	
}
