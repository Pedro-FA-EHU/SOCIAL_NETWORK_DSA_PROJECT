package packUser;

import packEx.*;

public class Person {

	private String id;
	private String name;
	private String lastname;
	private String birthdate;
	private String gender;
	private String birthplace;
	private String home;
	private String[] studiedat;
	private String[] workplaces;
	private String[] films;
	private String friendships;
	private String groupcode= "G612498"; //groupcode by defect
	
	
	public Person(String pId,String pName,String pLastName,
			String pBirthDate,String pGender,String pBirthPlace, 
			String pHome, String[] pStudieDat, String[] pWorkPlaces, 
			String[] pFilms, String pGroupcode) throws EmptyIDEx{ //ExistingIDException
		if(pId==null || pId=="") {
			throw new EmptyIDEx();
		}
		
		else {
			id=pId;
			name=pName;
			lastname=pLastName;
			birthdate=pBirthDate;
			gender=pGender;
			birthplace=pBirthPlace;
			home=pHome;
			studiedat=pStudieDat;
			workplaces=pWorkPlaces;
			films=pFilms;
			//After reading "friends.txt" --> 
			//Relations among users are created in each person attribute "friendships".
			friendships="";
			groupcode=pGroupcode;
		}			
	}
	// Getters and Setters can be implemented depending on the Social Network possibilities. 
	//Maybe we want to know only someone id.
		public String getId() {
			return id;
		}
		
		public String getName() {
			return name;
		}
		
		public String getFriendships() {
			return friendships;
		}
		
		public void setFriendships(String s) {
			friendships=s;
		}
		
		@Override
		public String toString() {			
			String studieDat = new String();
			String workPlaces = new String();
			String films = new String();
			String friendships = new String();			
			//Array to String Transformation of studiedat
			try {
				for (int i=0;i<this.studiedat.length;i++) {
					studieDat+=this.studiedat[i]+",";
				}
				// Replacing last character of the String, "," --> ";" 
				studieDat=studieDat.substring(0,studieDat.length()-1)+";";
			} catch(NullPointerException e) {
				studieDat=";";
			}
			//Array to String Transformation of films
			try {
				for (int i=0;i<this.films.length;i++) {
					films+=this.films[i]+",";
				}
				// Replacing last character of the String, "," --> ";"
				films=films.substring(0,films.length()-1)+";";
			} catch(NullPointerException e) {
				workPlaces=";";
			}
			//Array to String Transformation of workplaces
			try {
				for (int i=0;i<this.workplaces.length;i++) {
					workPlaces+=this.workplaces[i]+",";
				}
				// Replacing last character of the String, "," --> ";"
				workPlaces=workPlaces.substring(0,workPlaces.length()-1)+";";
			} catch(NullPointerException e ) {
				films=";";
			}
			/*
			try{
			for (int i=0;i<this.friendships.length;i++) {
				friendships+=this.friendships[i]+",";
			}
			friendships=friendships.substring(0,friendships.length()-1)+";";
			}
			catch(NullPointerException e){
				friendships="";
			}
			*/
			return this.id+","+this.name+","+this.lastname+","+this.birthdate+","+this.gender+","
			+this.birthplace+","+this.home+","+studieDat+workPlaces+films+this.groupcode;
		}
}
