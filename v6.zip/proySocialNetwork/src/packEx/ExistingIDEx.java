package packEx;

public class ExistingIDEx extends Exception{
	public ExistingIDEx() {
		super();
	}
	public ExistingIDEx(String message) {
		super(message);
	}
}
