package packUser;
import packList.*;

public class UsersList extends LinkedList<Person>{
	//Constructor
	public UsersList () {
		super();
	}
}
