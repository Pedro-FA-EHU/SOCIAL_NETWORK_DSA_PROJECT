package packUser;

public class EmptyIDEx extends Exception{
	public EmptyIDEx() {
		super();
	}
	public EmptyIDEx(String message) {
		super(message);
	}
}
