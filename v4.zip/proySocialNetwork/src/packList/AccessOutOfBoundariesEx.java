package packList;

public class AccessOutOfBoundariesEx extends Exception{
	public AccessOutOfBoundariesEx() {
		super();
	}
	public AccessOutOfBoundariesEx(String message) {
		super(message);
	}
}
