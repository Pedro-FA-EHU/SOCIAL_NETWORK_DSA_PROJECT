package packList;

public class Node<E> {
	//Attributes
	private E value;
	private Node<E> next;
	//Constructors
	public Node (E pValue){
		value = pValue;
		next = null;
	}
	//Getters
	public E getValue() {
		return value;
	}
	public Node<E> getNext() {
		return next;
	}
	//Setters
	public void setValue(E pValue) {
		value = pValue;
	}
	public void setNext(Node<E> pNext) {
		next = pNext;
	}
}
